FreshCheck AI — offline food-spoilage demo
=========================================
Open index.html in a browser. No API key, backend, or build step is needed.

Included curated samples:
- Strawberry mold
- Orange mold
- Apple surface lesions (uncertain cause)
- Carrot mold
- Moldy bread

Features:
- Responsive UI with CSS styling
- Clickable sample cards and report panel
- Likely cause, signs, cautious health guidance, and recommended action
- Explicit confidence and “recommended edible” labels
- Upload/camera input that previews a photo only

Important:
This is a predefined educational demo, not a trained classifier. New photos are not automatically analyzed.
Confidence numbers are illustrative labels, not validated model accuracy. Food safety cannot be established from a photograph.
